# Assignment 3: A Baby Project
# Sephora Skincare Reviews Data Analysis
## 1. Opens up the product_info datafile.
### 1.1 Load the product_info Data


```python
# Import necessary libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Load the data
df = pd.read_csv('product_info.csv')

```

### 1.2 Overview of Data Set 

### Dataset Name: Sephora Skincare Reviews
**Source**: Kaggle

**Content**:
- Customer reviews for skincare and makeup products sold at Sephora
- Includes product names and ratings
- Pricing details (original price, sale price)
- Additional attributes such as ingredients, variation types, and sizes
- Availability indicators (limited edition, online only, out of stock)
- Consumer engagement metrics (loves count, total reviews)

**Key Statistical Insights**
- **No. of columns**: 27
- **No. of rows**: 8,494
- **Unique Products**: 8,415
- **Unique Brands**: 304
- **Brand with Most Products**: SEPHORA COLLECTION (Number of Products: 352)

Notable **Missing Values** in the dataset include:
- **variation_desc**: 7244 missing values (85.28%)
- **value_price_usd**: 8043 missing values (94.69%)
- **sale_price_usd**: 8224 missing values (96.82%)
- **child_max_price**: 5740 missing values (67.58%)
- **child_min_price**: 5740 missing values (67.58%)
 


### 1.2.1 Summary Statistics


```python
# 1.2 Data Overview
summary_statistics = data.describe(include='all')
summary_statistics
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_id</th>
      <th>product_name</th>
      <th>brand_id</th>
      <th>brand_name</th>
      <th>loves_count</th>
      <th>rating</th>
      <th>reviews</th>
      <th>size</th>
      <th>variation_type</th>
      <th>variation_value</th>
      <th>...</th>
      <th>online_only</th>
      <th>out_of_stock</th>
      <th>sephora_exclusive</th>
      <th>highlights</th>
      <th>primary_category</th>
      <th>secondary_category</th>
      <th>tertiary_category</th>
      <th>child_count</th>
      <th>child_max_price</th>
      <th>child_min_price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>8494</td>
      <td>8494</td>
      <td>8494.000000</td>
      <td>8494</td>
      <td>8.494000e+03</td>
      <td>8216.000000</td>
      <td>8216.000000</td>
      <td>6863</td>
      <td>7050</td>
      <td>6896</td>
      <td>...</td>
      <td>8494.000000</td>
      <td>8494.000000</td>
      <td>8494.000000</td>
      <td>6287</td>
      <td>8494</td>
      <td>8486</td>
      <td>7504</td>
      <td>8494.000000</td>
      <td>2754.000000</td>
      <td>2754.000000</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>8494</td>
      <td>8415</td>
      <td>NaN</td>
      <td>304</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2055</td>
      <td>7</td>
      <td>2729</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4417</td>
      <td>9</td>
      <td>41</td>
      <td>118</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>top</th>
      <td>P505461</td>
      <td>Discovery Set</td>
      <td>NaN</td>
      <td>SEPHORA COLLECTION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.7 oz/ 50 mL</td>
      <td>Size</td>
      <td>1.7 oz/ 50 mL</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>['Layerable Scent', 'Floral Scent']</td>
      <td>Skincare</td>
      <td>Women</td>
      <td>Perfume</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>1</td>
      <td>3</td>
      <td>NaN</td>
      <td>352</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>500</td>
      <td>4043</td>
      <td>374</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>64</td>
      <td>2420</td>
      <td>875</td>
      <td>568</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>5422.440546</td>
      <td>NaN</td>
      <td>2.917957e+04</td>
      <td>4.194513</td>
      <td>448.545521</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.219096</td>
      <td>0.073699</td>
      <td>0.279374</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.631622</td>
      <td>53.792023</td>
      <td>39.665802</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>1709.595957</td>
      <td>NaN</td>
      <td>6.609212e+04</td>
      <td>0.516694</td>
      <td>1101.982529</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.413658</td>
      <td>0.261296</td>
      <td>0.448718</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.379470</td>
      <td>58.765894</td>
      <td>38.685720</td>
    </tr>
    <tr>
      <th>min</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>1063.000000</td>
      <td>NaN</td>
      <td>0.000000e+00</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>3.000000</td>
      <td>3.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>5333.000000</td>
      <td>NaN</td>
      <td>3.758000e+03</td>
      <td>3.981725</td>
      <td>26.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>22.000000</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>6157.500000</td>
      <td>NaN</td>
      <td>9.880000e+03</td>
      <td>4.289350</td>
      <td>122.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>32.000000</td>
      <td>28.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>6328.000000</td>
      <td>NaN</td>
      <td>2.684125e+04</td>
      <td>4.530525</td>
      <td>418.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.000000</td>
      <td>59.000000</td>
      <td>42.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>8020.000000</td>
      <td>NaN</td>
      <td>1.401068e+06</td>
      <td>5.000000</td>
      <td>21281.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>105.000000</td>
      <td>570.000000</td>
      <td>400.000000</td>
    </tr>
  </tbody>
</table>
<p>11 rows × 27 columns</p>
</div>



### 1.2.2 Missing Data Summary


```python
# Calculate the number of missing values for each column
missing_values_count = data.isnull().sum()

# Get the data types of each column
data_types = data.dtypes

# Combine all the required details into a single DataFrame
missing_data_summary = pd.DataFrame({
    'Column': data.columns,
    'Dtype': data_types,
    'Missing Count': missing_values_count,
    'Missing Percentage (%)': (missing_values_count / data.shape[0]) * 100
})

# Keep the original order of columns in the dataset
missing_data_summary = missing_data_summary.reset_index(drop=True)

# Display the full summary
print("Missing Data Summary")
print(missing_data_summary)

```

    Missing Data Summary
                    Column    Dtype  Missing Count  Missing Percentage (%)
    0           product_id   object              0                0.000000
    1         product_name   object              0                0.000000
    2             brand_id    int64              0                0.000000
    3           brand_name   object              0                0.000000
    4          loves_count    int64              0                0.000000
    5               rating  float64            278                3.272899
    6              reviews  float64            278                3.272899
    7                 size   object           1631               19.201789
    8       variation_type   object           1444               17.000235
    9      variation_value   object           1598               18.813280
    10      variation_desc   object           7244               85.283730
    11         ingredients   object            945               11.125500
    12           price_usd  float64              0                0.000000
    13     value_price_usd  float64           8043               94.690370
    14      sale_price_usd  float64           8224               96.821286
    15     limited_edition    int64              0                0.000000
    16                 new    int64              0                0.000000
    17         online_only    int64              0                0.000000
    18        out_of_stock    int64              0                0.000000
    19   sephora_exclusive    int64              0                0.000000
    20          highlights   object           2207               25.983047
    21    primary_category   object              0                0.000000
    22  secondary_category   object              8                0.094184
    23   tertiary_category   object            990               11.655286
    24         child_count    int64              0                0.000000
    25     child_max_price  float64           5740               67.577113
    26     child_min_price  float64           5740               67.577113
    

## 2. Exploratory Data Analysis (EDA) - Summaries

### 2.1 Average Rating for Each Product Category
- **Objective**: Calculate average ratings for products by brand.
- **Insight**: Identifies top-performing brands based on customer ratings.


```python
# Pivot table for average rating by brand name
avg_rating_by_brand = df.groupby('brand_name')['rating'].mean().reset_index()

# Sort the results from high to low ratings
avg_rating_by_brand = avg_rating_by_brand.sort_values(by='rating', ascending=False)

# Print the title and the DataFrame
print("Average Rating by Brand Name:\n")
print(avg_rating_by_brand)
```

    Average Rating by Brand Name:
    
               brand_name    rating
    78        Erno Laszlo  5.000000
    10              Aquis  4.904800
    158   MACRENE actives  4.889420
    161              MARA  4.823860
    32             CANOPY  4.813733
    ..                ...       ...
    47   Christophe Robin  3.154767
    101    Good Dye Young  3.062050
    194           Overose  2.848450
    253         The Maker       NaN
    299        philosophy       NaN
    
    [304 rows x 2 columns]
    

### 2.2 List of Products with Ratings Above 4.5 and Minimum Lovescount = 200000
- **Objective**: Filter products with high ratings and significant popularity.
- **Insight**: Highlights successful, high-quality products in the market.


```python
# Define criteria
rating_threshold = 4.5
min_loves_count = 200000

# Filter products based on criteria
filtered_products = df[
    (df['rating'] > rating_threshold) &
    (df['loves_count'] >= min_loves_count)
].copy()  # Create a copy to avoid SettingWithCopyWarning

# Sort by rating
filtered_products = filtered_products.sort_values(by='rating', ascending=False)

print("List of Products with Ratings Above 4.5 and Minimum Lovescount = 200000\n")

# Display relevant columns
print(filtered_products[['brand_name', 'product_name', 'rating', 'loves_count']])
```

    List of Products with Ratings Above 4.5 and Minimum Lovescount = 200000
    
                           brand_name  \
    5922                   PATRICK TA   
    251       Anastasia Beverly Hills   
    256       Anastasia Beverly Hills   
    252       Anastasia Beverly Hills   
    7983                  Urban Decay   
    248       Anastasia Beverly Hills   
    5250                         NARS   
    7341                        tarte   
    7986                  Urban Decay   
    8430           Yves Saint Laurent   
    2523      Fenty Beauty by Rihanna   
    7847                    Too Faced   
    987                         Buxom   
    2527      Fenty Beauty by Rihanna   
    5254                         NARS   
    988                         Buxom   
    5060                  Moroccanoil   
    7340                        tarte   
    8185                  Viktor&Rolf   
    7982                  Urban Decay   
    7977                  Urban Decay   
    6244  Rare Beauty by Selena Gomez   
    7652                 The Ordinary   
    1155                       CHANEL   
    5873             PAT McGRATH LABS   
    7913              Tower 28 Beauty   
    2130    Dr. Dennis Gross Skincare   
    529             Benefit Cosmetics   
    8429           Yves Saint Laurent   
    6242  Rare Beauty by Selena Gomez   
    2534      Fenty Beauty by Rihanna   
    1898                         Dior   
    7981                  Urban Decay   
    3874                         Kaja   
    2635             First Aid Beauty   
    3236                    Hourglass   
    7064               Sol de Janeiro   
    7134                        stila   
    7914              Tower 28 Beauty   
    7979                  Urban Decay   
    7659                 The Ordinary   
    4458                Laura Mercier   
    2859                     Givenchy   
    
                                               product_name  rating  loves_count  
    5922  Major Beauty Headlines - Double-Take Crème & P...  4.8471       218384  
    251               Modern Renaissance Eye Shadow Palette  4.7931       460449  
    256                                 Sun Dipped Glow Kit  4.7197       228037  
    252                         Soft Glam Eyeshadow Palette  4.7068       329192  
    7983                            24/7 Moondust Eyeshadow  4.6801       278053  
    248        DIPBROW Waterproof, Smudge Proof Brow Pomade  4.6701       617437  
    5250                                              Blush  4.6643       840076  
    7341         Tartelette In Bloom Clay Eyeshadow Palette  4.6624       359779  
    7986                       Naked Heat Eyeshadow Palette  4.6585       206040  
    8430                          Black Opium Eau de Parfum  4.6369       276396  
    2523                 Gloss Bomb Universal Lip Luminizer  4.6357       968317  
    7847                     Chocolate Soleil Matte Bronzer  4.6250       286081  
    987                   Full-On Plumping Lip Polish Gloss  4.6250       464024  
    2527                    Killawatt Freestyle Highlighter  4.6240       472069  
    5254                                 Audacious Lipstick  4.6191       330693  
    988                    Full-On Plumping Lip Cream Gloss  4.6163       241538  
    5060                     Moroccanoil Treatment Hair Oil  4.6131       206601  
    7340                       Amazonian Clay 12-Hour Blush  4.6131       375001  
    8185                                         Flowerbomb  4.5850       232390  
    7982                       Heavy Metal Glitter Eyeliner  4.5840       286897  
    7977                            Vice Hydrating Lipstick  4.5825       593515  
    6244              Warm Wishes Effortless Bronzer Sticks  4.5792       361417  
    7652      AHA 30% + BHA 2% Exfoliating Peeling Solution  4.5734       533877  
    1155                    COCO MADEMOISELLE Eau de Parfum  4.5667       257774  
    5873                                    LUST: Lip Gloss  4.5563       207742  
    7913                 ShineOn Lip Jelly Non-Sticky Gloss  4.5531       383024  
    2130          Alpha Beta Extra Strength Daily Peel Pads  4.5455       234295  
    529   Precisely, My Brow Pencil Waterproof Eyebrow D...  4.5425       278187  
    8429                  Rouge Volupté Shine Lipstick Balm  4.5384       373458  
    6242                            Soft Pinch Liquid Blush  4.5356      1401068  
    2534                 Sun Stalk'r Instant Warmth Bronzer  4.5320       231534  
    1898                        BACKSTAGE Glow Face Palette  4.5317       229844  
    7981                            Eyeshadow Primer Potion  4.5273       305092  
    3874                    Eye Bento Bouncy Eyeshadow Trio  4.5255       334894  
    2635               Ultra Repair Cream Intense Hydration  4.5200       300432  
    3236                  Ambient Lighting Blush Collection  4.5190       267732  
    7064                                    Bum Bum Jet Set  4.5094       256184  
    7134                   Glitter & Glow Liquid Eye Shadow  4.5079       462133  
    7914                BeachPlease Lip + Cheek Cream Blush  4.5070       257946  
    7979                                     24/7 Eyeshadow  4.5045       426543  
    7659          Lactic Acid 10% + HA 2% Exfoliating Serum  4.5035       295071  
    4458                   Translucent Loose Setting Powder  4.5029       813497  
    2859    Prisme Libre Loose Setting and Finishing Powder  4.5020       204028  
    

### 2.3 Average Price by Category and New Products
- **Objective**: Analyze average prices by product category and new status.
- **Insight**: Reveals pricing trends, aiding marketing and inventory decisions.


```python
# Create a pivot table to calculate average price by primary category and new status
pivot_avg_price = df.pivot_table(values='price_usd', index='primary_category', columns='new', aggfunc='mean', fill_value=0)

# Rename columns for clarity
pivot_avg_price.columns = ['Not New', 'New']

# Resetting index to make the table more user-friendly
pivot_avg_price.reset_index(inplace=True)

# Print the title
print("Average Price by Primary Category and New Status\n")

# Display the pivot table
print(pivot_avg_price)
```

    Average Price by Primary Category and New Status
    
      primary_category    Not New        New
    0      Bath & Body  43.229223  30.625000
    1        Fragrance  86.562077  96.300971
    2            Gifts  50.000000   0.000000
    3             Hair  42.074373  51.730370
    4           Makeup  32.879357  30.896552
    5              Men  33.200000   0.000000
    6        Mini Size  21.066540  24.880000
    7         Skincare  59.845359  68.167423
    8  Tools & Brushes  32.559000  16.000000
    

## 3. Exploratory Data Analysis (EDA) - Charts

### 3.1 Histogram: Distribution of Customer Ratings for Skincare Products
- **Objective**: Visualize customer rating distribution for skincare products.
- **Insight**: Illustrates overall customer satisfaction levels across all products, providing a comprehensive view of rating trends 


```python
# Calculate average ratings by brand
top_brands = df.groupby('brand_id')['rating'].mean().reset_index()

# Sort by average rating and get the top 10
top_brands = top_brands.sort_values(by='rating', ascending=False).head(10)

# Plotting
plt.figure(figsize=(10, 6))
sns.histplot(df['rating'], bins=10, kde=True)  # Ensure 'df' is used if 'data' is not defined
plt.title('Distribution of Customer Ratings for Skincare Products')
plt.xlabel('Rating')
plt.ylabel('Frequency')
plt.grid(axis='y', linestyle='--', linewidth=0.5, alpha=0.5)  # Dashed line, less bold
plt.show()
```


    
![png](output_17_0.png)
    


### 3.2 Bar Chart: Average Loves Count by Primary Category
- **Objective**: Compare average loves counts across product categories.
- **Insight**: Indicates customer loyalty and helps focus marketing efforts.


```python
# 2.2 Calculate average loves count by primary category
average_loves_count_by_category = df.groupby('primary_category')['loves_count'].mean().sort_values(ascending=False)

# Plotting the bar chart
plt.figure(figsize=(12, 6))
average_loves_count_by_category.plot(kind='bar', color='lightgreen')
plt.title('Average Loves Count by Primary Category')
plt.xlabel('Primary Category')
plt.ylabel('Average Loves Count')
plt.xticks(rotation=45)
plt.grid(axis='y')
plt.tight_layout()  # Adjust layout to make room for labels
plt.show()
```


    
![png](output_19_0.png)
    


### 3.3 Pie Chart: Proportion of Sephora Exclusive Products
- **Objective**: Visualize the share of exclusive vs. non-exclusive products.
- **Insight**: Informs inventory and marketing strategies regarding exclusivity.


```python
# Count the number of exclusive and non-exclusive products
sephora_exclusive_count = df['sephora_exclusive'].value_counts()

# Plotting the pie chart
plt.figure(figsize=(8, 8))
plt.pie(sephora_exclusive_count, labels=sephora_exclusive_count.index, autopct='%1.1f%%', startangle=140, colors=['lightblue', 'lightcoral'])
plt.title('Proportion of Sephora Exclusive Products')
plt.axis('equal')  # Equal aspect ratio ensures the pie chart is circular.
plt.show()
```


    
![png](output_21_0.png)
    


### 3.4 Sephora Skincare Reviews Dataset Analysis Summary
The **Sephora Skincare Reviews** dataset offers valuable insights into skincare products, emphasizing customer ratings and preferences. 
Key analyses include:

- **Average Ratings**: Identifies top-performing brands based on customer feedback.
- **High-Quality Products**: Highlights products with ratings above 4.5 and a minimum loves count, indicating significant popularity and market success.
- **Pricing Trends**: Analyzes average prices by product category, aiding marketing strategies and inventory management.
- **Customer Satisfaction**: Visualizes the distribution of customer ratings, reflecting overall satisfaction levels with various products.
- **Customer Loyalty**: Compares average loves counts across categories, indicating levels of brand loyalty among consumers.
- **Product Exclusivity**: Shows the proportion of exclusive versus non-exclusive products, informing inventory and targeted marketing initiatives.

